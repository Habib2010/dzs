<?php

namespace Croogo\Blocks\Model\Entity;

use Cake\ORM\Entity;

class Region extends Entity
{

}
