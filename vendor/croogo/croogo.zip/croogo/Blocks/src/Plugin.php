<?php

namespace Croogo\Blocks;

use Cake\Core\BasePlugin;

class Plugin extends BasePlugin
{
}
