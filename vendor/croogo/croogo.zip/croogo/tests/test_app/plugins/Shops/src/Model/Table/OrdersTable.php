<?php

namespace Shops\Model\Table;

use Croogo\Core\Model\Table\CroogoTable;

class OrdersTable extends CroogoTable
{

    public $useTable = false;
}
