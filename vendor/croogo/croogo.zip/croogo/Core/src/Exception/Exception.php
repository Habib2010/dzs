<?php

namespace Croogo\Core\Exception;

class Exception extends \Cake\Core\Exception\Exception
{

}
