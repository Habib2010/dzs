<?php

namespace Croogo\Contacts;

use Cake\Core\BasePlugin;

class Plugin extends BasePlugin
{
}
