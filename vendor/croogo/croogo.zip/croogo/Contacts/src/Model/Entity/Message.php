<?php

namespace Croogo\Contacts\Model\Entity;

use Cake\ORM\Entity;

class Message extends Entity
{

}
