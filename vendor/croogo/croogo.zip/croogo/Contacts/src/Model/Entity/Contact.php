<?php

namespace Croogo\Contacts\Model\Entity;

use Cake\ORM\Behavior\Translate\TranslateTrait;
use Cake\ORM\Entity;

class Contact extends Entity
{

    use TranslateTrait;
}
