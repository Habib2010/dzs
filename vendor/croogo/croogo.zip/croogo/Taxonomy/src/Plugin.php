<?php

namespace Croogo\Taxonomy;

use Cake\Core\BasePlugin;

class Plugin extends BasePlugin
{
}
