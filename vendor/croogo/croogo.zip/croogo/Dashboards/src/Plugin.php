<?php

namespace Croogo\Dashboards;

use Cake\Core\BasePlugin;

class Plugin extends BasePlugin
{
}
