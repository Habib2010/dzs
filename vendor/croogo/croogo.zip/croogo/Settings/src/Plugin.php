<?php

namespace Croogo\Settings;

use Cake\Core\BasePlugin;

class Plugin extends BasePlugin
{
}
