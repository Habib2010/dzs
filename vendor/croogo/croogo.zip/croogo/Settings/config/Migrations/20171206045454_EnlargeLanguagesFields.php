<?php

use Migrations\AbstractMigration;

class EnlargeLanguagesFields extends AbstractMigration
{
    public function change()
    {
    }
}
