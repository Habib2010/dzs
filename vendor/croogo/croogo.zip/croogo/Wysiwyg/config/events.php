<?php

namespace Croogo\Wysiwyg\Config;

return [
    'EventHandlers' => [
        'Croogo/Wysiwyg.WysiwygEventHandler',
    ],
];
