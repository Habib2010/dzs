<?php

use Migrations\AbstractMigration;

class UpgradeMenus extends AbstractMigration
{
    public function change()
    {
    }
}
