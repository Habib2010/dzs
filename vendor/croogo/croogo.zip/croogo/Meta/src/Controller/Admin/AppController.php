<?php

namespace Croogo\Meta\Controller\Admin;

use Croogo\Core\Controller\Admin\AppController as BaseController;

/**
 * Meta App Controller
 *
 * @category Meta.Controller
 * @package  Croogo.Meta
 * @license  http://www.opensource.org/licenses/mit-license.php The MIT License
 * @link     http://www.croogo.org
 */
class AppController extends BaseController
{

}
