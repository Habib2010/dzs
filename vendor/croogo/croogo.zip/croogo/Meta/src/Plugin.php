<?php

namespace Croogo\Meta;

use Cake\Core\BasePlugin;

class Plugin extends BasePlugin
{
}
