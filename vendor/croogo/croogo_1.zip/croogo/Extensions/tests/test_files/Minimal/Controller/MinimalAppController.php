<?php
namespace Croogo\Extensions\Test\test_files\Minimal\Controller;

class MinimalAppController extends AppController
{
}
