<?php

class_alias('Croogo\Core\PluginManager', 'Croogo\Extensions\CroogoPlugin');
