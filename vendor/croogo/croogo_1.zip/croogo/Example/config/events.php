<?php

namespace Croogo\Example\Config;

return [
    'EventHandlers' => [
        'Croogo/Example.ExampleEventHandler' => [
            'options' => [
                'priority' => 1,
            ],
        ],
    ],
];
