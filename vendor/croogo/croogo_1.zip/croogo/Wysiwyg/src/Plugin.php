<?php

namespace Croogo\Wysiwyg;

use Cake\Core\BasePlugin;

class Plugin extends BasePlugin
{
}
