<?php

use Migrations\AbstractMigration;

class MenusAddForeignKeys extends AbstractMigration
{
    public function change()
    {
    }
}
