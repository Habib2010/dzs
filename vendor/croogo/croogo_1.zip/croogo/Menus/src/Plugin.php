<?php

namespace Croogo\Menus;

use Cake\Core\BasePlugin;

class Plugin extends BasePlugin
{
}
