# Croogo/Dashboards Plugin

This repository is a **read-only** split of the main Croogo code.

# Documentation

Please see the [documentation](http://docs.croogo.org/3.0)
