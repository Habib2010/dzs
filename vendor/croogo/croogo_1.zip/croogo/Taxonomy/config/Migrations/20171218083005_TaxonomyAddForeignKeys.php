<?php

use Migrations\AbstractMigration;

class TaxonomyAddForeignKeys extends AbstractMigration
{
    public function change()
    {
    }
}
