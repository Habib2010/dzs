<?php

namespace Croogo\Taxonomy\Config;

return [
    'EventHandlers' => [
        'Croogo/Taxonomy.TaxonomiesEventHandler',
    ],
];
