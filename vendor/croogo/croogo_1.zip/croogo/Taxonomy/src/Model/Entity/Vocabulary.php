<?php

namespace Croogo\Taxonomy\Model\Entity;

use Cake\ORM\Entity;

class Vocabulary extends Entity
{

}
