<?php

namespace Croogo\Taxonomy\Model\Table;

use Croogo\Core\Model\Table\CroogoTable;

class TypesVocabulariesTable extends CroogoTable
{
}
