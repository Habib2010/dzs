<?php

use Migrations\AbstractMigration;

class BlocksAddForeignKeys extends AbstractMigration
{
    public function change()
    {
    }
}
