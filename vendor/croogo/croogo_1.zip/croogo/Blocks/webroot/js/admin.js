/**
 * document ready
 *
 * @return void
 */
$(function() {
  Admin.toggleRowSelection('#BlocksCheckAll');
});
