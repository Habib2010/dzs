<?php

use Migrations\AbstractMigration;

class NodesAddForeignKeys extends AbstractMigration
{
    public function change()
    {
    }
}
