<?php

namespace Croogo\Nodes\Config;

return [
    'EventHandlers' => [
        'Croogo/Nodes.NodesEventHandler',
    ],
];
