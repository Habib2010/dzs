<?php

namespace Croogo\Meta\Model\Entity;

use Cake\ORM\Entity;

class Meta extends Entity
{
}
