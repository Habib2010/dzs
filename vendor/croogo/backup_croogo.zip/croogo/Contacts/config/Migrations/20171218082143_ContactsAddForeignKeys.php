<?php

use Migrations\AbstractMigration;

class ContactsAddForeignKeys extends AbstractMigration
{
    public function change()
    {
    }
}
