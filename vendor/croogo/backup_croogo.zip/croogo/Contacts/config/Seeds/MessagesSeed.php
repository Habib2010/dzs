<?php

use Phinx\Seed\AbstractSeed;

class MessagesSeed extends AbstractSeed
{

    public $records = [
    ];
}
