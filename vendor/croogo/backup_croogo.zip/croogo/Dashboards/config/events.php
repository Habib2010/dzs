<?php

return [
    'EventHandlers' => [
        'Croogo/Dashboards.DashboardsEventHandler' => [
            'options' => [
                'priority' => 5,
            ],
        ],
    ],
];
