<?php

use Migrations\AbstractMigration;

class DashboardsAddForeignKeys extends AbstractMigration
{
    public function change()
    {
    }
}
