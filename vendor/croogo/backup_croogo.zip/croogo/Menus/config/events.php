<?php

return [
    'EventHandlers' => [
        'Croogo/Menus.MenusEventHandler',
    ],
];
