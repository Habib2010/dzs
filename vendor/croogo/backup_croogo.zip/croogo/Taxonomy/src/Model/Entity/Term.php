<?php

namespace Croogo\Taxonomy\Model\Entity;

use Cake\ORM\Behavior\Translate\TranslateTrait;
use Cake\ORM\Entity;

class Term extends Entity
{

    use TranslateTrait;
}
