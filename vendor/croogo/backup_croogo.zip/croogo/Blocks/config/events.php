<?php

namespace Croogo\Blocks\Config;

return [
    'EventHandlers' => [
        'Croogo/Blocks.BlocksEventHandler',
    ],
];
