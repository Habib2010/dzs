<?php

namespace Croogo\Example\View\Cell;

use Cake\View\Cell;

class ExampleDashboardCell extends Cell
{

    public function welcome()
    {
    }
}
