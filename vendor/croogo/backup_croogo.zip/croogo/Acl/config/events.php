<?php

return [
    'EventHandlers' => [
        'Croogo/Acl.AclEventHandler',
    ],
];
