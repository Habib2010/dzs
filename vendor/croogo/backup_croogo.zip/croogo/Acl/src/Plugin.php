<?php

namespace Croogo\Acl;

use Cake\Core\BasePlugin;

class Plugin extends BasePlugin
{
}
