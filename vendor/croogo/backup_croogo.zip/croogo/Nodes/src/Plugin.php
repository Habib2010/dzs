<?php

namespace Croogo\Nodes;

use Cake\Core\BasePlugin;

class Plugin extends BasePlugin
{
}
