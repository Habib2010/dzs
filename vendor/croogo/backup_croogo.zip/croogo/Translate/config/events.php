<?php

namespace Croogo\Translate\Config;

return [
    'EventHandlers' => [
        'Croogo/Translate.TranslateEventHandler' => [
            'options' => [
                'priority' => 20,
            ],
        ],
    ],
];
