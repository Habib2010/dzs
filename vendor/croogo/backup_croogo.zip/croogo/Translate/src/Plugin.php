<?php

namespace Croogo\Translate;

use Cake\Core\BasePlugin;

class Plugin extends BasePlugin
{
}
